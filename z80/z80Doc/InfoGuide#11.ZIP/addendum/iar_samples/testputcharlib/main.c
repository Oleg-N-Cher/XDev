#include <stdio.h>
#include <intrz80.h>
#include "../mylib/mylib.h"
C_task void main(void)
{
	scr_init(0x07<<3);
	puts("Hello World!");
	while(1) printf("Keyboard scan: 0x%02X\r",input(0x00fe));
}
