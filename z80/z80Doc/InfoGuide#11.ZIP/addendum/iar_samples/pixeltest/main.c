#include <math.h>
//#define FASTPIXEL
#include "../mylib/mylib.h"
C_task void main(void){
	unsigned char x=0;
	scr_init(0x07<<3);
	set_pix_init();
	do{
		set_pix(x,(sin((double)x/20)*20+95));
	}while(++x);
}
