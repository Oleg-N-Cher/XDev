#include <stdio.h>
#include <intrz80.h>
#include "../mylib/mylib.h"
unsigned int int_count=0;
interrupt void myint(void){
	int_count++;
	output8(0xfe,((unsigned char)int_count&0x70)>>4);
}
C_task void main(void){
	my_im2_init(myint);
	enable_interrupt();
	scr_init(0x07<<3);
	puts("Hello World!");
	while(1) printf("Keyboard scan: 0x%02X\r",input(0x00fe));
}