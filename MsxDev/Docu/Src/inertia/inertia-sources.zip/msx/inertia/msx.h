#ifndef ___MSX_H___
#define ___MSX_H___

void putchar(char chr);
char getchar(void);
void gotoxy(char x,char y);
void cls(void);
char joystick(char n);
char joytrig(char n);
char peek(int address);
int peek_word(int address);
void poke(int address, char value);
void poke_word(int address, int value);
void exit(void);
char is_ctrl_break();

#endif
