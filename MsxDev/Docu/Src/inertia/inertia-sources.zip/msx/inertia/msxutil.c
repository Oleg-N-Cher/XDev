#include "msxutil.h"
#include "msx.h"
#include <stdio.h>
#include <string.h>

char text_choice(int msgs, int chosen, char *title, char *msg[]){
  char i;

  gotoxy(6, 1); puts(title);

  gotoxy(6, 2);
  for (i = 0; i < strlen(title); i++) { putchar(192); }

  for (i = 0; i < msgs; i++) {
    gotoxy(6, 4 + 2 * i); puts(msg[i]);
  }

  gotoxy(3, 4 + 2 * chosen); puts("=>");

  while (!(joytrig(0) | joytrig(1) | joytrig(2))) {    
    if ((i = joystick(0) | joystick(1) | joystick(2)) != 0) {
      
      gotoxy(3, 4 + 2 * chosen); puts("  ");
      
      switch (i) {
        case 1:
          chosen = (chosen + msgs - 1) % msgs;
        break;
        case 5:
          chosen = (chosen + 1) % msgs;
        break;
      }

      gotoxy(3, 4 + 2 * chosen);
      puts("=>");

      while (joystick(0) | joystick(1) | joystick(2)) { }
    }
  }

  while (joytrig(0) | joytrig(1) | joytrig(2)) { }

  return chosen;
}

