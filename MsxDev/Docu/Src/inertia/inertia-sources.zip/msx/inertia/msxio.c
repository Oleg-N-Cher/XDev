#include "msx.h"
#include <stdio.h>
#include <string.h>

void exit(void) { while(1); }

void putchar(char chr) {
  _asm
    ld a,4(ix)
    call 0x00A2
  _endasm;
}
      
char getchar(void) {
  _asm
    call 0x009F
    ld   h,#0x00
    ld   l,a
  _endasm;
}

void gotoxy(char x,char y) {
  _asm
    ld h,4(ix)
    ld l,5(ix)
    call 0x00C6
  _endasm;
}

void clrscr(void) {
  putchar(0x1b);
  putchar(0x45);
}

char joystick(char n){
  _asm
    ld a,4(ix)
    call 0x00d5
    ld l,a
  _endasm;
}

char joytrig(char n){
  _asm
    ld a,4(ix)
    call 0x00d8
    ld h,#0x00
    ld l,a
  _endasm;
}

char peek(int address){
  _asm
    ld l,4(ix)
    ld h,5(ix)
    ld l,(hl)
    ld h,#0x00
  _endasm;
}

int peek_word(int address){
  return
    ((int)peek(address)&0xff) |
    (peek(address+1)<<8) ;
}

void poke(int address, char value){
  _asm
    ld l,4(ix)
    ld h,5(ix)
    ld a,6(ix)
    ld (hl),a
  _endasm;
}

void poke_word(int address, int value){
  poke(address,value&0xff);
  poke(address+1, value&0xff00 >> 8);
}

char vpeek(int address){
  _asm
    ld l,4(ix)
    ld h,5(ix)
    call 0x004a
    ld h,#0x00
    ld l,a
  _endasm;
}

void vpoke(int address, char value){
  _asm
    ld l,4(ix)
    ld h,5(ix)
    ld a,6(ix)
    call 0x004d
  _endasm;
}

void vpoke_block(int address, char* block, int size){
  while (size-->0){ vpoke(address++,*(block++)); }
}

void vdp_set(char vdpregister, char value){
  _asm
    di
    ld a,5(ix)
    out (0x99),a ; --- put data
    ld a,4(ix)   ; --- choose register
    or #0x80     ; --- set register-write mode
    out (0x99),a ; --- write data in register
    ei
  _endasm;
}

void vdp_mask(char vdpregister, char and_mask, char or_mask){
  _asm
    di
    ld a,4(ix)   ; choose register
    and #0x7f    ; specify register-read mode
    out (0x99),a ; send command
    in a,(0x98)  ; read data
    ld c,#0x02
    or c
    out (0x99),a ; set data to write
    ld a,4(ix)   ; choose register
    or #0x80     ; set reg-write mode
    out (0x99),a ; send data
    ei
  _endasm;

}

void sprite_create(char number, unsigned char* profile, char spritesize){
  int mem=peek_word(T32PAT)+(number&0xff)*(spritesize&0xff);
  vpoke_block(mem, profile, spritesize);
}

void sprite_put(char number, char xpos, char ypos, char color){
  unsigned int mem=peek_word(T32ATR)+(number&0xff)*4;
  vpoke(mem+0,ypos);
  vpoke(mem+1,xpos);
  //vpoke(mem+2,number+1);
  vpoke(mem+3,color);
}

void wait_vrt(){
  _asm
$1:
  di
  in a,(0x99)
  and #0x80
  cp #0x00
  jr z, $1
  ei
  _endasm;
}
