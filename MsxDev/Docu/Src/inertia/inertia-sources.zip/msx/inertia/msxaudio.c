void sound_set(char reg, char val){
  _asm
  ld a, 4(ix)
  ld e, 5(ix)
  call 0x0093  
  _endasm;
}

char sound_get(char reg){
  _asm
  ld a, 4(ix)  
  call 0x0096
  ld l,a
  _endasm;
}


