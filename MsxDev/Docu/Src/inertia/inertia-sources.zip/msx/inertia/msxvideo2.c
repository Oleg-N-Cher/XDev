 void screen_setup(char spritesize, char zoom){
 _endasm;
 void screen_color(char fg, char bg, char bd){
 _endasm;
 char vpeek(int address){
 _endasm;
 void vpoke(int address, char value){
 _endasm;
 void vpoke_block(int address, char* block, int size){
 while (size-->0){ vpoke(address++,*(block++)); }
 void sprite_profile(char number, unsigned char* profile, char spritesize){
 int mem=peek_word(T32PAT)+(number&0xff)*(spritesize&0xff);
 vpoke_block(mem, profile, spritesize);
 void sprite_put(char number, char xpos, char ypos, char color){
 unsigned int mem=peek_word(T32ATR)+(number&0xff)*4;
 vpoke(mem+0,ypos);
 vpoke(mem+1,xpos);
 vpoke(mem+3,color);
 void wait_retrace(){
 _endasm;
 void screen1_setup_chars(){
 off=peek_word(T32CGP)+'A'*8;
 for (sz=0;sz<26*8;sz++){
 vpoke( off, vpeek(off)|vpeek(off)>>1);
 off++;
 for (sz=0;sz<26*8;sz++){
 off=peek_word(T32CGP)+'a'*8;
 for (sz=0;sz<26*8;sz++){
 vpoke( off, vpeek(off)|vpeek(off)>>1);
 off++;
 for (sz=0;sz<26*8;sz++){
 off=peek_word(T32CGP)+'0'*8;
 for (sz=0;sz<10*8;sz++){
 vpoke( off, vpeek(off)|vpeek(off)>>1);
 off++;
 for (sz=0;sz<10*8;sz++){
 off=peek_word(T32COL)+'0'/8;
 vpoke(off++,0xC0);
 vpoke(off++,0xC0);
 off=peek_word(T32COL)+'A'/8;
 vpoke(off++,0x20);
 vpoke(off++,0x20);
 vpoke(off++,0x20);
 vpoke(off++,0x20);
 off=peek_word(T32COL)+'a'/8;
 vpoke(off++,0x20);
 vpoke(off++,0x20);
 vpoke(off++,0x20);
 vpoke(off++,0x20);
 off=peek_word(T32COL)+'\310'/8;
 vpoke(off++,0x50);
